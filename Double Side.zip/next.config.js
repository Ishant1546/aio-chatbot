// next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
    // Your custom Next.js configuration
  };
  
  module.exports = nextConfig;