// src/hooks/useChat.ts
import { useState, useCallback } from 'react';
import { Message, Chat, AIModel } from '@/types/chat';
import { v4 as uuidv4 } from 'uuid';

export function useChat() {
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  
  const sendMessage = useCallback(async (content: string, model: AIModel) => {
    try {
      setLoading(true);
      
      // Create user message
      const userMessage: Message = {
        id: uuidv4(),
        role: 'user',
        content,
        timestamp: Date.now(),
      };
      
      // Add user message to UI
      setMessages((prev) => [...prev, userMessage]);
      
      // Format messages for API
      const apiMessages = [...messages, userMessage].map(({ role, content }) => ({
        role,
        content,
      }));
      
      // Send to API
      const response = await fetch('/api/chat/send-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: apiMessages,
          model: model.id,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }
      
      const data = await response.json();
      
      // Create AI message
      const aiMessage: Message = {
        id: uuidv4(),
        role: 'assistant',
        content: data.message.content,
        timestamp: Date.now(),
      };
      
      // Add AI message to UI
      setMessages((prev) => [...prev, aiMessage]);
      
      // Save to database
      const isNewChat = !activeChat;
      const title = isNewChat ? content.substring(0, 30) + '...' : undefined;
      
      const saveResponse = await fetch('/api/chat/save-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chatId: activeChat?.id,
          message: aiMessage,
          isNewChat,
          title,
          model: model.id,
        }),
      });
      
      if (!saveResponse.ok) {
        throw new Error('Failed to save message');
      }
      
      const saveData = await saveResponse.json();
      
      // Update active chat if new
      if (isNewChat && saveData.chatId) {
        setActiveChat({
          id: saveData.chatId,
          title: title || 'New Chat',
          messages: [userMessage, aiMessage],
          model: model,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
      }
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setLoading(false);
    }
  }, [messages, activeChat]);
  
  return {
    messages,
    setMessages,
    activeChat,
    setActiveChat,
    sendMessage,
    loading,
  };
}