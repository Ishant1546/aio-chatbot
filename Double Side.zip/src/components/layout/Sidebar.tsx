// src/components/layout/Sidebar.tsx
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase/client';

type ChatItem = {
  id: string;
  title: string;
};

export function Sidebar() {
  const [chats, setChats] = useState<ChatItem[]>([]);
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    async function loadChats() {
      try {
        const response = await fetch('/api/load-history');
        if (response.ok) {
          const data = await response.json();
          setChats(data.chats || []);
        }
      } catch (error) {
        console.error('Failed to load chats:', error);
      }
    }

    loadChats();
  }, []);

  return (
    <aside
      className={`bg-gray-800 text-white transition-all duration-300 ${
        isOpen ? 'w-64' : 'w-0'
      }`}
    >
      {isOpen && (
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b border-gray-700 p-4">
            <h2 className="text-xl font-bold">Chats</h2>
            <button
              onClick={() => setIsOpen(false)}
              className="rounded-full p-1 hover:bg-gray-700"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>
          </div>
          
          <div className="p-4">
            <Link
              href="/chat"
              className="flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 4v16m8-8H4"
                />
              </svg>
              <span>New Chat</span>
            </Link>
          </div>
          
          <nav className="flex-1 overflow-y-auto p-4">
            <ul className="space-y-1">
              {chats.map((chat) => (
                <li key={chat.id}>
                  <Link href={`/chat/${chat.id}`} className="block rounded-md px-4 py-2 hover:bg-gray-700">
                    {chat.title}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}

      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="absolute left-0 top-4 rounded-r-md bg-gray-800 p-2 text-white"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </button>
      )}
    </aside>
  );
}