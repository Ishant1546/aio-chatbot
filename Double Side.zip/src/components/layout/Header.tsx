// src/components/layout/Header.tsx
'use client';

import Link from 'next/link';
import ThemeToggle from './ThemeToggle';

export function Header() {
  return (
    <header className="border-b border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
      <div className="flex h-16 items-center justify-between px-4">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold">AI Chatbot</span>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <ThemeToggle />
          {/* Add user menu or login button here */}
        </div>
      </div>
    </header>
  );
}