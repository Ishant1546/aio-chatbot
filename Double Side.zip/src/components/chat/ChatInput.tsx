// src/components/chat/ChatInput.tsx
import { useState } from 'react';
import { AIModel } from '@/types/chat';

interface ChatInputProps {
  onSendMessage: (content: string, model: AIModel) => void;
  loading: boolean;
  selectedModel: AIModel;
  setSelectedModel: (model: AIModel) => void;
}

export default function ChatInput({ 
  onSendMessage, 
  loading, 
  selectedModel,
  setSelectedModel 
}: ChatInputProps) {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !loading) {
      onSendMessage(message, selectedModel);
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white p-2 shadow-sm dark:border-gray-700 dark:bg-gray-800">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Message AI..."
            className="flex-1 bg-transparent px-2 py-1 outline-none"
            rows={1}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <button
            type="submit"
            disabled={loading || !message.trim()}
            className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:bg-blue-400"
          >
            {loading ? 'Sending...' : 'Send'}
          </button>
        </div>
      </div>
    </form>
  );
}