// src/components/chat/ChatList.tsx
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';

type ChatItem = {
  id: string;
  title: string;
  updated_at: string;
};

export default function ChatList() {
  const [chats, setChats] = useState<ChatItem[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    async function loadChats() {
      try {
        setLoading(true);
        const response = await fetch('/api/load-history');
        if (response.ok) {
          const data = await response.json();
          setChats(data.chats || []);
        }
      } catch (error) {
        console.error('Failed to load chats:', error);
      } finally {
        setLoading(false);
      }
    }

    loadChats();
  }, []);

  if (loading) {
    return (
      <div className="p-4">
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-10 animate-pulse rounded-md bg-gray-700"></div>
          ))}
        </div>
      </div>
    );
  }

  if (chats.length === 0) {
    return (
      <div className="p-4 text-center text-gray-400">
        <p>No chats yet</p>
        <p className="text-sm">Start a new conversation</p>
      </div>
    );
  }

  return (
    <ul className="space-y-1">
      {chats.map((chat) => (
        <li key={chat.id}>
          <Link 
            href={`/chat/${chat.id}`}
            className={`block rounded-md px-4 py-2 ${
              pathname === `/chat/${chat.id}` 
                ? 'bg-gray-700 text-white' 
                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`}
          >
            <div className="truncate">{chat.title}</div>
            <div className="text-xs text-gray-400">
              {new Date(chat.updated_at).toLocaleDateString()}
            </div>
          </Link>
        </li>
      ))}
    </ul>
  );
}