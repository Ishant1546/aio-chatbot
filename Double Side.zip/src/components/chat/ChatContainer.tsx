// src/components/chat/ChatContainer.tsx
import { useRef, useEffect } from 'react';
import { Message as MessageType } from '@/types/chat';
import Message from './Message';

interface ChatContainerProps {
  messages: MessageType[];
  loading: boolean;
}

export default function ChatContainer({ messages, loading }: ChatContainerProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.length === 0 ? (
        <div className="flex h-full items-center justify-center">
          <div className="text-center text-gray-500 dark:text-gray-400">
            <h2 className="text-2xl font-bold">Welcome to AI Chat</h2>
            <p className="mt-2">Start a conversation with an AI assistant.</p>
          </div>
        </div>
      ) : (
        <>
          {messages.map((message) => (
            <Message key={message.id} message={message} />
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="rounded-lg bg-gray-100 px-4 py-2 dark:bg-gray-700">
                <div className="flex space-x-2">
                  <div className="h-2 w-2 animate-pulse rounded-full bg-gray-400"></div>
                  <div className="h-2 w-2 animate-pulse rounded-full bg-gray-400 animation-delay-200"></div>
                  <div className="h-2 w-2 animate-pulse rounded-full bg-gray-400 animation-delay-400"></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </>
      )}
    </div>
  );
}