// src/types/chat.ts
export interface Message {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: number;
  }
  
  export interface Chat {
    id: string;
    userId?: string;
    title: string;
    messages: Message[];
    model: AIModel;
    createdAt: number;
    updatedAt: number;
  }
  
  export type AIModel = {
    id: string;
    name: string;
    provider: string;
    description?: string;
    maxTokens?: number;
    pricePer1MTokens?: number;
  };
  
  export const availableModels: AIModel[] = [
    {
      id: "anthropic/claude-3-opus",
      name: "Claude 3 Opus",
      provider: "Anthropic",
      description: "Most powerful model for complex tasks"
    },
    {
      id: "openai/gpt-4",
      name: "GPT-4",
      provider: "OpenAI",
      description: "Advanced reasoning and instruction following"
    },
    {
      id: "google/gemini-1.5-pro",
      name: "Gemini 1.5 Pro",
      provider: "Google",
      description: "Versatile model with strong multimodal capabilities"
    },
    {
      id: "deepseek/deepseek-chat",
      name: "DeepSeek Chat",
      provider: "DeepSeek",
      description: "Open-source model with competitive performance"
    },
    {
      id: "xai/grok-1",
      name: "Grok",
      provider: "xAI",
      description: "Real-time information and witty responses"
    },
    // Add more models as needed
  ];