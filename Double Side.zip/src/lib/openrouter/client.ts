// src/lib/openrouter/client.ts
export async function sendMessageToAI(messages: any[], model: string) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "HTTP-Referer": process.env.NEXT_PUBLIC_SITE_URL,
          "X-Title": "AI Chatbot"
        },
        body: JSON.stringify({
          model: model,
          messages: messages,
          stream: false
        }),
      });
  
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }
  
      const data = await response.json();
      return data.choices[0].message;
    } catch (error) {
      console.error("Error calling OpenRouter API:", error);
      throw error;
    }
  }