// src/app/page.tsx
import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="flex h-full flex-col items-center justify-center p-4">
      <div className="max-w-3xl text-center">
        <h1 className="text-4xl font-bold">Welcome to AI Chatbot</h1>
        <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
          Chat with multiple AI models including GPT-4, Claude, Gemini, and more - all in one place.
        </p>
        <div className="mt-8">
          <Link
            href="/chat"
            className="rounded-md bg-blue-600 px-6 py-3 text-lg font-medium text-white hover:bg-blue-700"
          >
            Start Chatting
          </Link>
        </div>
      </div>
    </div>
  );
}