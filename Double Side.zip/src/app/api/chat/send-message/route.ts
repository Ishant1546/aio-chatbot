// src/app/api/chat/send-message/route.ts
import { NextResponse } from 'next/server';
import { sendMessageToAI } from '@/lib/openrouter/client';

export async function POST(request: Request) {
  try {
    const { messages, model } = await request.json();
    
    // Call OpenRouter API
    const aiResponse = await sendMessageToAI(messages, model);
    
    return NextResponse.json({ message: aiResponse });
  } catch (error) {
    console.error('Error in send-message API route:', error);
    return NextResponse.json(
      { error: 'Failed to send message to AI' },
      { status: 500 }
    );
  }
}