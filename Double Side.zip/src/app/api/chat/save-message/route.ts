// src/app/api/chat/save-message/route.ts
import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

export async function POST(request: Request) {
  try {
    const cookieStore = cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
        },
      }
    );
    
    const { chatId, message, isNewChat, title, model } = await request.json();
    
    const { data: { user } } = await supabase.auth.getUser();
    
    if (isNewChat) {
      // Create a new chat
      const { data, error } = await supabase
        .from('chats')
        .insert({
          user_id: user?.id,
          title: title || 'New Chat',
          messages: [message],
          model: model
        })
        .select('id')
        .single();
      
      if (error) throw error;
      
      return NextResponse.json({ success: true, chatId: data.id });
    } else {
      // Update existing chat
      const { data: chat, error: chatError } = await supabase
        .from('chats')
        .select('messages')
        .eq('id', chatId)
        .single();
      
      if (chatError) throw chatError;
      
      const updatedMessages = [...chat.messages, message];
      
      const { error: updateError } = await supabase
        .from('chats')
        .update({ 
          messages: updatedMessages,
          updated_at: new Date()
        })
        .eq('id', chatId);
      
      if (updateError) throw updateError;
      
      return NextResponse.json({ success: true });
    }
  } catch (error) {
    console.error('Error in save-message API route:', error);
    return NextResponse.json(
      { error: 'Failed to save message' },
      { status: 500 }
    );
  }
}