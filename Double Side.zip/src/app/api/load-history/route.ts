// src/app/api/load-history/route.ts
import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

export async function GET(request: Request) {
  try {
    const cookieStore = cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
        },
      }
    );
    
    const { searchParams } = new URL(request.url);
    const chatId = searchParams.get('chatId');
    
    if (chatId) {
      // Load a specific chat
      const { data, error } = await supabase
        .from('chats')
        .select('*')
        .eq('id', chatId)
        .single();
      
      if (error) throw error;
      
      return NextResponse.json({ chat: data });
    } else {
      // Load all chats for the user
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return NextResponse.json({ chats: [] });
      }
      
      const { data, error } = await supabase
        .from('chats')
        .select('id, title, model, created_at, updated_at')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      
      return NextResponse.json({ chats: data });
    }
  } catch (error) {
    console.error('Error in load-history API route:', error);
    return NextResponse.json(
      { error: 'Failed to load chat history' },
      { status: 500 }
    );
  }
}