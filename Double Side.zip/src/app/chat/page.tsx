// src/app/chat/page.tsx
'use client';

import { useState } from 'react';
import { useChat } from '@/hooks/useChat';
import { availableModels } from '@/types/chat';
import ChatInput from '@/components/chat/ChatInput';
import Message from '@/components/chat/Message';
import ModelSelector from '@/components/chat/ModelSelector';

export default function ChatPage() {
  const [selectedModel, setSelectedModel] = useState(availableModels[0]);
  const { messages, sendMessage, loading } = useChat();

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-gray-200 px-4 py-2 dark:border-gray-700">
        <h1 className="text-xl font-semibold">New Chat</h1>
        <ModelSelector selectedModel={selectedModel} onSelectModel={setSelectedModel} />
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex h-full items-center justify-center">
            <div className="text-center text-gray-500 dark:text-gray-400">
              <h2 className="text-2xl font-bold">Welcome to AI Chat</h2>
              <p className="mt-2">Start a conversation with an AI assistant.</p>
            </div>
          </div>
        ) : (
          messages.map((message) => <Message key={message.id} message={message} />)
        )}
      </div>

      <div className="border-t border-gray-200 p-4 dark:border-gray-700">
        <ChatInput
          onSendMessage={sendMessage}
          loading={loading}
          selectedModel={selectedModel}
          setSelectedModel={setSelectedModel}
        />
      </div>
    </div>
  );
}