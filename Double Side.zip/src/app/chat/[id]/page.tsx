// src/app/chat/[id]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useChat } from '@/hooks/useChat';
import { useParams, useRouter } from 'next/navigation';
import { availableModels, AIModel } from '@/types/chat';
import ChatInput from '@/components/chat/ChatInput';
import Message from '@/components/chat/Message';
import ModelSelector from '@/components/chat/ModelSelector';

export default function ChatPage() {
  const params = useParams();
  const router = useRouter();
  const { messages, setMessages, activeChat, setActiveChat, sendMessage, loading } = useChat();
  const [selectedModel, setSelectedModel] = useState<AIModel>(availableModels[0]);
  const chatId = params.id;

  useEffect(() => {
    async function loadChat() {
      try {
        const response = await fetch(`/api/load-history?chatId=${chatId}`);
        if (response.ok) {
          const data = await response.json();
          if (data.chat) {
            setActiveChat(data.chat);
            setMessages(data.chat.messages);
            // Find the model from availableModels
            const model = availableModels.find(m => m.id === data.chat.model) || availableModels[0];
            setSelectedModel(model);
          } else {
            // Chat not found, redirect to new chat
            router.push('/chat');
          }
        }
      } catch (error) {
        console.error('Failed to load chat:', error);
        router.push('/chat');
      }
    }

    if (chatId) {
      loadChat();
    }
  }, [chatId, router, setActiveChat, setMessages]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-gray-200 px-4 py-2 dark:border-gray-700">
        <h1 className="text-xl font-semibold">
          {activeChat?.title || 'Loading...'}
        </h1>
        <ModelSelector selectedModel={selectedModel} onSelectModel={setSelectedModel} />
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <Message key={message.id} message={message} />
        ))}
      </div>

      <div className="border-t border-gray-200 p-4 dark:border-gray-700">
        <ChatInput
          onSendMessage={sendMessage}
          loading={loading}
          selectedModel={selectedModel}
          setSelectedModel={setSelectedModel}
        />
      </div>
    </div>
  );
}